//
//  ViewController.m
//  MyLayoutDemo
//
//  Created by HaoCold on 2022/2/9.
//

#import "ViewController.h"
#import "CustomView.h"

@interface ViewController ()
@property (nonatomic,  strong) CustomView *view1;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.view addSubview:self.view1];
}

- (CustomView *)view1{
    if (!_view1) {
        _view1 = [[CustomView alloc] initWithFrame:self.view.bounds];
    }
    return _view1;
}


@end

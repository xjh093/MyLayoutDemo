//
//  CustomView.h
//  MyLayoutDemo
//
//  Created by HaoCold on 2022/2/9.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomView : UIView

@end

NS_ASSUME_NONNULL_END

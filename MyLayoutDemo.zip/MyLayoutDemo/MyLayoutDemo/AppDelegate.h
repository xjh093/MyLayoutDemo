//
//  AppDelegate.h
//  MyLayoutDemo
//
//  Created by HaoCold on 2022/2/9.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;

@end


//
//  CustomView.m
//  MyLayoutDemo
//
//  Created by HaoCold on 2022/2/9.
//

#import "CustomView.h"
#import "MyFloatLayout.h"
#import "UIView+Add.h"

// 设置为 1 时，没问题，scrollView 可以滚动，对应图片0
/*
 视图结构是这样的：
 CustomView
 - UIScrollView
  - UIView
   - MyFloatLayout
    - UIButton
 */


// 为 0 时，对应图片1，无法滚动，_secondLabel 的位置也不对 （#2，#3，都不打开）
// 只打开 标记 #2 对应行，对应图片2，可以滚动
// 只打开 标记 #3 对应行，对应图片3，无法滚动
/*
 视图结构是这样的：
 CustomView
 - UIScrollView
   - MyFloatLayout
    - UIButton
 */

#define kOpen 1

@interface CustomView()
@property (nonatomic,  strong) UIScrollView *scrollView;
@property (nonatomic,  strong) UILabel *firstLabel;
#if kOpen
@property (nonatomic,  strong) UIView *itemView;
#else
@property (nonatomic,  strong) MyFloatLayout *itemView;
#endif
@property (nonatomic,  strong) UILabel *secondLabel;
@property (nonatomic,  strong) UILabel *thirdLabel;
@property (nonatomic,  strong) UILabel *forthLabel;

@end

@implementation CustomView

#pragma mark -------------------------------------视图-------------------------------------------

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self xjh_setupViews];
    }
    return self;
}

- (void)xjh_setupViews
{
    [self addSubview:self.scrollView];
    [self.scrollView addSubview:self.firstLabel];
    [self.scrollView addSubview:self.itemView];
    [self.scrollView addSubview:self.secondLabel];
    [self.scrollView addSubview:self.thirdLabel];
    [self.scrollView addSubview:self.forthLabel];
    
    //
    _itemView.top = _firstLabel.bottom + 10;
#if kOpen
#else
//    [_itemView layoutIfNeeded]; // #2 只打这行，对应图片2
//    CGSize size = [_itemView sizeThatFits:(CGSizeMake(self.frame.size.width, 0))];
#endif
    
    
    //
    _secondLabel.top = _itemView.bottom + 200;
//    _secondLabel.top = _itemView.top + size.height + 200;
    
    //
    _thirdLabel.top = _secondLabel.bottom + 200;
    
    //
    _forthLabel.top = _thirdLabel.bottom + 200;
    
    //
    _scrollView.contentSize = CGSizeMake(_scrollView.width, _forthLabel.bottom + 200);
}

#pragma mark -------------------------------------事件-------------------------------------------

#pragma mark -------------------------------------懒加载-----------------------------------------

- (UIScrollView *)scrollView{
    if (!_scrollView) {
        UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
        //scrollView.showsVerticalScrollIndicator = NO;
        _scrollView = scrollView;
    }
    return _scrollView;
}

- (UILabel *)firstLabel{
    if (!_firstLabel) {
        UILabel *label = [[UILabel alloc] init];
        label.frame = CGRectMake(15, 120, 100, 20);
        label.text = @"firstLabel";
        label.textColor = [UIColor blackColor];
        label.font = [UIFont systemFontOfSize:14];
        label.textAlignment = NSTextAlignmentLeft;
        _firstLabel = label;
    }
    return _firstLabel;
}

#if kOpen
- (UIView *)itemView{
    if (!_itemView) {
        _itemView = [[UIView alloc] init];
#else
- (MyFloatLayout *)itemView{
    if (!_itemView) {
#endif
        MyFloatLayout * floatLayout = [[MyFloatLayout alloc] initWithOrientation:MyOrientation_Vert];
        floatLayout.subviewVSpace = 10;
        floatLayout.subviewHSpace = 20;
        floatLayout.paddingLeft = 15;
        floatLayout.myWidth = CGRectGetWidth(self.bounds);
        floatLayout.myHeight = MyLayoutSize.wrap;
        //floatLayout.adjustScrollViewContentSizeMode = MyAdjustScrollViewContentSizeModeNo;
        floatLayout.backgroundColor = [UIColor orangeColor];
        
        // 选项
        NSArray *arr = @[@"标题1",@"标题12",@"标题123",@"标题1234",@"标题12345",@"标题1标题1",@"标题1标题12",@"标题1标题123",@"标题1标题1234"];
        for (NSInteger i = 0; i < arr.count; i++) {
            NSInteger tag = i + 1;
            NSString *title = arr[i];
            
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.tag = tag;
            button.backgroundColor = [UIColor lightGrayColor];
            button.titleLabel.font = [UIFont systemFontOfSize:14];
            [button setTitle:title forState:0];
            [button sizeToFit];
            [floatLayout addSubview:button];
        }
        
#if kOpen
        [_itemView addSubview:floatLayout];
        [floatLayout layoutIfNeeded];
        _itemView.frame = floatLayout.bounds;
#else
//        [floatLayout layoutIfNeeded]; // #3 只打这行，对应图片3
        _itemView = floatLayout;
#endif
    }
    return _itemView;
}

- (UILabel *)secondLabel{
    if (!_secondLabel) {
        UILabel *label = [[UILabel alloc] init];
        label.frame = CGRectMake(15, 20, 100, 20);
        label.text = @"secondLabel";
        label.textColor = [UIColor blackColor];
        label.font = [UIFont systemFontOfSize:14];
        label.textAlignment = NSTextAlignmentLeft;
        _secondLabel = label;
    }
    return _secondLabel;
}

- (UILabel *)thirdLabel{
    if (!_thirdLabel) {
        UILabel *label = [[UILabel alloc] init];
        label.frame = CGRectMake(15, 20, 100, 20);
        label.text = @"thirdLabel";
        label.textColor = [UIColor blackColor];
        label.font = [UIFont systemFontOfSize:14];
        label.textAlignment = NSTextAlignmentLeft;
        _thirdLabel = label;
    }
    return _thirdLabel;
}

- (UILabel *)forthLabel{
    if (!_forthLabel) {
        UILabel *label = [[UILabel alloc] init];
        label.frame = CGRectMake(15, 20, 100, 20);
        label.text = @"forthLabel";
        label.textColor = [UIColor blackColor];
        label.font = [UIFont systemFontOfSize:14];
        label.textAlignment = NSTextAlignmentLeft;
        _forthLabel = label;
    }
    return _forthLabel;
}

@end
